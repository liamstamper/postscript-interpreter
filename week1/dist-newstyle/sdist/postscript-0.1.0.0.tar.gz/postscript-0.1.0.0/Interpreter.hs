module Interpreter (interprete) where

import Language
import Graphics.Rendering.Cairo hiding (x)

-- The state is the current operand stack, the dictionary stack, and the graphics state.
data State = State
  { operandStack  :: [PSExpr]        -- Operand stack
  , dictStack     :: [Dictionary]   -- Dictionary stack
  , graphicsState :: GraphicsState  -- Graphics rendering state
  } deriving (Show)

-- Graphics rendering parameters
data GraphicsState = GraphicsState
  { currentColor :: (Double, Double, Double) -- RGB color
  , lineWidth    :: Double                   -- Line width
  } deriving (Show)

-- Default initial graphics state
defaultGraphicsState :: GraphicsState
defaultGraphicsState = GraphicsState
  { currentColor = (0, 0, 0)  -- Default color: Black
  , lineWidth = 1.0           -- Default line width
  }

-- The main interpreter function
interprete :: PSExpr -> Render (Result State)
interprete (PSProcedure exprs) = runProgram exprs initialState
  where
    initialState = State [] [sysdict] defaultGraphicsState
interprete _ = return $ Left ("Invalid program format: Expected a PSProcedure", undefinedState)

-- Initial undefined state for error handling
undefinedState :: State
undefinedState = State [] [] defaultGraphicsState

-- Run a sequence of PostScript expressions
runProgram :: [PSExpr] -> State -> Render (Result State)
runProgram [] state = return $ Right state
runProgram (PSOp op : rest) state = do
  result <- evalOp op state
  case result of
    Left err -> return $ Left err
    Right newState -> runProgram rest newState
runProgram _ state = return $ Left ("Unexpected expression in program", state)

-- Evaluate a PostScript operator
evalOp :: PSBuiltin -> State -> Render (Result State)
evalOp PSdup state =
  case operandStack state of
    (x:xs) -> return $ Right state { operandStack = x : x : xs }
    []     -> return $ Left ("dup: Stack underflow", state)

evalOp PSpop state =
  case operandStack state of
    (_:xs) -> return $ Right state { operandStack = xs }
    []     -> return $ Left ("pop: Stack underflow", state)

evalOp PSexch state =
  case operandStack state of
    (x:y:xs) -> return $ Right state { operandStack = y : x : xs }
    _        -> return $ Left ("exch: Stack underflow", state)

evalOp PSadd state =
  case operandStack state of
    (PSInt x : PSInt y : xs) ->
      return $ Right state { operandStack = PSInt (x + y) : xs }
    _ -> return $ Left ("add: Invalid operands", state)

evalOp PSsub state =
  case operandStack state of
    (PSInt x : PSInt y : xs) ->
      return $ Right state { operandStack = PSInt (y - x) : xs }
    _ -> return $ Left ("sub: Invalid operands", state)

evalOp PSmul state =
  case operandStack state of
    (PSInt x : PSInt y : xs) ->
      return $ Right state { operandStack = PSInt (x * y) : xs }
    _ -> return $ Left ("mul: Invalid operands", state)

evalOp PSdiv state =
  case operandStack state of
    (PSInt 0 : _) -> return $ Left ("div: Division by zero", state)
    (PSInt x : PSInt y : xs) ->
      return $ Right state { operandStack = PSInt (y `div` x) : xs }
    _ -> return $ Left ("div: Invalid operands", state)

evalOp PSneg state =
  case operandStack state of
    (PSInt x : xs) ->
      return $ Right state { operandStack = PSInt (-x) : xs }
    _ -> return $ Left ("neg: Invalid operand", state)

-- Graphics operators
evalOp PSmoveto state =
  case operandStack state of
    (PSReal y : PSReal x : xs) -> do
      moveTo x y
      return $ Right state { operandStack = xs }
    _ -> return $ Left ("moveto: Invalid operands", state)

evalOp PSlineto state =
  case operandStack state of
    (PSReal y : PSReal x : xs) -> do
      lineTo x y
      return $ Right state { operandStack = xs }
    _ -> return $ Left ("lineto: Invalid operands", state)

evalOp PSstroke state = do
  stroke
  return $ Right state

evalOp PSnewpath state = do
  newPath
  return $ Right state

evalOp PSsetlinewidth state =
  case operandStack state of
    (PSReal w : xs) -> do
      setLineWidth w
      return $ Right state { operandStack = xs }
    _ -> return $ Left ("setlinewidth: Invalid operand", state)

evalOp PSsetrgbcolor state =
  case operandStack state of
    (PSReal b : PSReal g : PSReal r : xs) -> do
      setSourceRGB r g b
      return $ Right state { operandStack = xs, graphicsState = (graphicsState state) { currentColor = (r, g, b) } }
    _ -> return $ Left ("setrgbcolor: Invalid operands", state)

-- Handle unknown operators
evalOp _ state = return $ Left ("Unimplemented operator", state)